#include <ros/ros.h>
#include <pcl/common/transforms.h>
#include "glog/logging.h"

#include "lidar_localization/global_defination/global_defination.h"
#include "lidar_localization/subscriber/cloud_subscriber.hpp"
#include "lidar_localization/subscriber/imu_subscriber.hpp"
#include "lidar_localization/subscriber/gnss_subscriber.hpp"
#include "lidar_localization/tf_listener/tf_listener.hpp"
#include "lidar_localization/publisher/cloud_publisher.hpp"
#include "lidar_localization/publisher/odometry_publisher.hpp"

using namespace lidar_localization;

int main(int argc, char *argv[])
{
    google::InitGoogleLogging(argv[0]);
    FLAGS_log_dir = WORK_SPACE_PATH + "/Log";
    FLAGS_alsologtostderr = 1;

    ros::init(argc, argv, "test_frame_node");
    ros::NodeHandle nh;
    //这一块，和接下来的一些内容，都是使用了智能指针，并初始化节点，用来订阅后面的话题名称
    //std::make_shared 是一个辅助函数，用于创建一个 shared_ptr
    std::shared_ptr<CloudSubscriber> cloud_sub_ptr = std::make_shared<CloudSubscriber>(nh, "/kitti/velo/pointcloud", 100000);
    std::shared_ptr<IMUSubscriber> imu_sub_ptr = std::make_shared<IMUSubscriber>(nh, "/kitti/oxts/imu", 1000000);
    std::shared_ptr<GNSSSubscriber> gnss_sub_ptr = std::make_shared<GNSSSubscriber>(nh, "/kitti/oxts/gps/fix", 1000000);
    std::shared_ptr<TFListener> lidar_to_imu_ptr = std::make_shared<TFListener>(nh, "velo_link", "imu_link");

    std::shared_ptr<CloudPublisher> cloud_pub_ptr = std::make_shared<CloudPublisher>(nh, "current_scan", 100, "map");
    std::shared_ptr<OdometryPublisher> odom_pub_ptr = std::make_shared<OdometryPublisher>(nh, "lidar_odom", "map", "lidar", 100);
    //这里的发布的话题，是我们能够在rviz中看到的，雷达当前的扫描，保存的点数，在map上的多少，以及雷达里程计的信息


    //这些都是定义的容器,可以认为是缓存区
    std::deque<CloudData> cloud_data_buff;
    std::deque<IMUData> imu_data_buff;
    std::deque<GNSSData> gnss_data_buff;
    
    //变量的初始化，用于管理状态与转移矩阵
    Eigen::Matrix4f lidar_to_imu = Eigen::Matrix4f::Identity();//这是创建一个单位矩阵给它，初始化一下
    //用来看看是否成功收到变换矩阵与gnss的初始位置
    bool transform_received = false;
    bool gnss_origin_position_inited = false;


    ros::Rate rate(100);

    while (ros::ok())
    {
        ros::spinOnce();//调用回调函数
        
        //ParseData：这是上述类中的一个方法，用于处理从相应 ROS 话题接收到的数据
        //这里的智能指针指向了接受到的数据
        cloud_sub_ptr->ParseData(cloud_data_buff);
        imu_sub_ptr->ParseData(imu_data_buff);
        gnss_sub_ptr->ParseData(gnss_data_buff);


        if (!transform_received)
        {
            if (lidar_to_imu_ptr->LookupData(lidar_to_imu))
            //lookupdata是用来查询数据变换是否成功的，如果说成功，那么就说转换关系接受，这一块首先判断有没有数据，然后完成初始化
            {
                transform_received = true;
            }
        }
            else
            {
                while (cloud_data_buff.size() > 0 && imu_data_buff.size() > 0 &&gnss_data_buff.size() > 0)
                {
                    CloudData cloud_data = cloud_data_buff.front();
                    IMUData imu_data = imu_data_buff.front();
                    GNSSData gnss_data = gnss_data_buff.front();
                    

                    //这一段是用来进行时间同步的
                    double d_time = cloud_data.time - imu_data.time;
                    if (d_time < -0.05)
                    {
                        cloud_data_buff.pop_front();//这里就是移去第一个元素，因为d<0.05的时候
                        //意味着点云的时间磋要早与imu，因此移除掉第一个数据，认为其是过时的
                    }
                    else if (d_time > 0.05)
                    {
                        imu_data_buff.pop_front();
                        gnss_data_buff.pop_front();
                    }
                     else 
                        {
                            cloud_data_buff.pop_front();
                            imu_data_buff.pop_front();
                            gnss_data_buff.pop_front();

                            Eigen::Matrix4f odometry_matrix;//时间上同步，进行后续处理

                            if (!gnss_origin_position_inited)//初始化
                            {
                                gnss_data.InitOriginPosition();
                                gnss_origin_position_inited = true;

                            }
                            
                            gnss_data.UpdateXYZ();
                            odometry_matrix(0,3) = gnss_data.local_E;//笛卡尔坐标，东，北，上（海拔）
                            odometry_matrix(1,3) = gnss_data.local_N;
                            odometry_matrix(2,3) = gnss_data.local_U;
                            odometry_matrix.block<3,3>(0,0) = imu_data.GetOrientationMatrix();
                            odometry_matrix *= lidar_to_imu;

                            pcl::transformPointCloud(*cloud_data.cloud_ptr, *cloud_data.cloud_ptr, odometry_matrix);

                            cloud_pub_ptr->Publish(cloud_data.cloud_ptr);
                            odom_pub_ptr->Publish(odometry_matrix);

                        }

                }
                
            }
            rate.sleep();
            
        }
        return 0;
        
    }
    
