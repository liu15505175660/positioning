#include "lidar_localization/sensor_data/gnss_data.hpp"
#include "glog/logging.h"//生成日记用的


bool lidar_localization::GNSSData::origin_position_inited = false;
//这里进行的是静态成员变量的类外初始化
GeographicLib::LocalCartesian lidar_localization::GNSSData::geo_converter;

namespace lidar_localization
{
    void GNSSData::InitOriginPosition()
    {
        geo_converter.Reset(latitude, longitude, altitude);
        origin_position_inited = true;

    }

    void GNSSData::UpdateXYZ()
    {
        if (!origin_position_inited)
        {   
                LOG(WARNING) << "GeoConverter has not set origin position";
        }
        geo_converter.Forward(latitude, longitude, altitude, local_E, local_N, local_U);
        
    }
}