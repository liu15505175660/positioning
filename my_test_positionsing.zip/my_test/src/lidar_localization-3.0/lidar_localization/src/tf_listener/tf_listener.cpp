#include <Eigen/Geometry>
#include "lidar_localization/tf_listener/tf_listener.hpp"

namespace lidar_localization
{
    TFListener::TFListener(ros::NodeHandle& nh, std::string base_frame_id, std::string child_frame_id):
    nh_(nh), base_frame_id_(base_frame_id), child_frame_id_(child_frame_id)
    {}//定义，初始化
    bool TFListener::LookupData(Eigen::Matrix4f& transform_matrix)
    //bool类型，判断类函数Lookupdata，查询是否转移与变换成功
    {
        try
        {
            tf::StampedTransform transform;//这是个用来存临时变换的变量
            listener_.lookupTransform(base_frame_id_,child_frame_id_,ros::Time(0), transform);//这个用来查两个坐标系之间的变换关系
            TransformToMatrix(transform, transform_matrix);//主要是个转换关系，这里是转化为更容易处理的线性数据库格式
            return true;
        }
        //try语句用于捕捉可能出现的异常
        catch(tf::TransformException &ex)
        {
            return false;
        }    
    }

    //这个玩意主要是查询ros里面 两个坐标帧之间的变换，然后将这个坐标转换的关系，变成一个矩阵



    bool TFListener::TransformToMatrix(const tf::StampedTransform& transform, Eigen::Matrix4f& transform_matrix)

    {
        Eigen::Translation3f t1_btol(transform.getOrigin().getX(), transform.getOrigin().getY(), transform.getOrigin().getZ());
        //translation3f是一个库，表示的是三维空间中的平移
        //然后在括号内进行参数的构造，得到对象transform的原点的，x，y，z的坐标。
        //getorigin返回的是一个vector的平移部分

        double roll, pitch, yaw;
        tf::Matrix3x3(transform.getRotation()).getEulerYPR(yaw, pitch, roll);
        Eigen::AngleAxisf rot_x_btol(roll, Eigen::Vector3f::UnitX());
        Eigen::AngleAxisf rot_y_btol(pitch, Eigen::Vector3f::UnitY());
        Eigen::AngleAxisf rot_z_btol(yaw, Eigen::Vector3f::UnitZ());
        //定义的旋转角度关系


        //t1_btol是父坐标系的原点，然后这个就是子坐标系到父坐标系的转换，不过这里好像只有旋转
        transform_matrix = (t1_btol * rot_z_btol * rot_y_btol * rot_x_btol).matrix();

        return true;
    }

}