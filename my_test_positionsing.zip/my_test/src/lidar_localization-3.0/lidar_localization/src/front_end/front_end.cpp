//前段里程计的实现算法

#include <cmath>
#include <pcl/common/transforms.h>
#include "glog/logging.h"
#include "lidar_localization/front_end/front_end.hpp"
#include <memory>

namespace lidar_localization
{
    FrontEnd::FrontEnd()
    :ndt_ptr_(new pcl::NormalDistributionsTransform<CloudData::POINT, CloudData::POINT>()),
    //进行了ndt方法的初始化
    local_map_ptr_(new CloudData::CLOUD()),
    global_map_ptr_(new CloudData::CLOUD()),
    result_cloud_ptr_(new CloudData::CLOUD())
    //像前面这都是他的参数初始化
    {
        cloud_filter_.setLeafSize(1.3, 1.3, 1.3);
        local_map_filter_.setLeafSize(0.6, 0.6, 0.6);
        display_filter_.setLeafSize(0.5, 0.5, 0.5);
        ndt_ptr_->setResolution(1.0);
        ndt_ptr_->setStepSize(0.1);
        ndt_ptr_->setTransformationEpsilon(0.01);
        ndt_ptr_->setMaximumIterations(30);
        //这些都是使用ndt的默认参数，包括滤波的系数等等
    }

    Eigen::Matrix4f FrontEnd::Update(const CloudData& cloud_data)
    {
        current_frame_.cloud_data.time = cloud_data.time;//时间赋值，时间磋同步
        std::vector<int> indices;
        //包括这一段其实是点云更新滤波的过程，我们将最终的结果保存至filtered_cloud_ptr
        //利用函数移除nan错误值，三个参数表示清除前，清除后，无nan时的索引
        pcl::removeNaNFromPointCloud(*cloud_data.cloud_ptr, *current_frame_.cloud_data.cloud_ptr,indices);

        CloudData::CLOUD_PTR filtered_cloud_ptr(new CloudData::CLOUD());
        cloud_filter_.setInputCloud(current_frame_.cloud_data.cloud_ptr);
        cloud_filter_.filter(*filtered_cloud_ptr);
        //这里放了过滤后的结果

        //这一块是进行的矩阵初始化
        static Eigen::Matrix4f step_pose = Eigen::Matrix4f::Identity();
        static Eigen::Matrix4f last_pose = init_pose_;
        static Eigen::Matrix4f predict_pose = init_pose_;
        static Eigen::Matrix4f last_key_frame_pose = init_pose_;


        //局部地图进行匹配,是第一帧时就将第一帧作为关键帧
        if (local_map_frames_.size()==0)
        {
            current_frame_.pose = init_pose_;
            UpdateNewFrame(current_frame_);
            return current_frame_.pose;
        }
        
        //利用ndt算法来正常匹配点云
        ndt_ptr_->setInputSource(filtered_cloud_ptr);
        //这一行是执行点云配准的过程，尝试将上方的输入点云进行配准，参数分别表示变换后的配准变换后的点云与初始变换猜想
        ndt_ptr_->align(*result_cloud_ptr_, predict_pose);
        //获取完成配准后的最终变换矩阵，存入pose中
        current_frame_.pose = ndt_ptr_->getFinalTransformation();

        
        //根据距离判断是否生成关键帧
        if (fabs(last_key_frame_pose(0,3)-current_frame_.pose(0,3))+
        fabs(last_key_frame_pose(1,3)-current_frame_.pose(1,3))+
        fabs(last_key_frame_pose(2,3)-current_frame_.pose(2,3))>2.0)

        {
            UpdateNewFrame(current_frame_);
            last_key_frame_pose = current_frame_.pose;
        }

        return current_frame_.pose;//返回的当前的位置，然后可能会有个循环
    }


    //判断对初始与预测
    bool FrontEnd::SetInitPose(const Eigen::Matrix4f& init_pose)
    {
        init_pose_ = init_pose;
        return true;
    }

    bool FrontEnd::SetPredictPose(const Eigen::Matrix4f& predict_pose)
    {
        predict_pose_ = predict_pose;
        return true;
    }


        //关键帧点云的保存
    void FrontEnd::UpdateNewFrame(const Frame& new_key_frame)
    {
        Frame key_frame = new_key_frame;//矩阵，关键的帧数存在里面
        key_frame.cloud_data.cloud_ptr.reset(new CloudData::CLOUD(*new_key_frame.cloud_data.cloud_ptr));
        CloudData::CLOUD_PTR transformed_cloud_ptr(new CloudData::CLOUD);
        //生成了一个transformed的新智能指针，指向新分配的空对象，这里是用来存变换后的点云数据的，姿态变换

        //对局部地图的更新
        local_map_frames_.push_back(key_frame);//对关键帧进行返回
        while (local_map_frames_.size()>20)
        {
            local_map_frames_.pop_front();//限制关键帧的多少
        }

        local_map_ptr_.reset(new CloudData::CLOUD());
        
    for (size_t i = 0; i < local_map_frames_.size(); ++i) {
        pcl::transformPointCloud(*local_map_frames_.at(i).cloud_data.cloud_ptr, 
                                 *transformed_cloud_ptr, 
                                 local_map_frames_.at(i).pose);
        *local_map_ptr_ += *transformed_cloud_ptr;
    }
        has_new_local_map_ = true;


        //更新ndt匹配的目标点云
        if (local_map_frames_.size()<10)//滑动窗口大小
        {
            ndt_ptr_->setInputTarget(local_map_ptr_);
            //在帧数少于10的情况下，直接将 local_map_ptr_（指向当前局部地图的智能指针）设置为 NDT 算法的目标点云
        }
        else
        {
            CloudData::CLOUD_PTR filtered_local_map_ptr(new CloudData::CLOUD());
            local_map_filter_.setInputCloud(local_map_ptr_);
            local_map_filter_.filter(*filtered_local_map_ptr);
            //执行过滤操作，将结果存储在 filtered_local_map_ptr 指向的点云中。这通常涉及减少点云中的点数
            ndt_ptr_->setInputTarget(filtered_local_map_ptr);
        }
        
        //更新全局地图
        //利用关键帧的数量进行优化，保持效率和负载管理
         global_map_frames_.push_back(key_frame);
         if (global_map_frames_.size() % 100!=0)
         {
            return;
         }

         else//如果超出，进行全局地图的更新
         {
            //重新初始化全局地图的指针，为新的全局地图数据作准备
            global_map_frames_.reset(new CloudData::CLOUD());
            //遍历所有全局地图帧，对每一帧进行变化与合并
            for (size_t i = 0; i < global_map_frames_.size(); ++i)
            {
                // 点云变换
                pcl::transformPointCloud(*global_map_frames_.at(i).cloud_data.cloud_ptr,
                                        *transformed_cloud_ptr,
                                        global_map_frames_.at(i).pose);
                //点云的合并
                *global_map_ptr_ += *transformed_cloud_ptr;
                
            }
            has_new_global_map_ = true;
            
         }
    }




    //判断是否有新的点云，有的化进行过滤，最后的重点应该是local_map_ptr_，global_map_ptr与current_scan_ptr

        bool FrontEnd::GetNewLocalMap(CloudData::CLOUD_PTR& local_map_ptr_)
        {
            if (has_new_local_map_)
            {
                display_filter_.setInputCloud(local_map_ptr_);
                display_filter_.filter(*local_map_ptr_);
                return true;
            }
            return false;    
        }

    bool FrontEnd::GetNewGlobalMap(CloudData::CLOUD_PTR& global_map_ptr) {
    if (has_new_global_map_) {
        display_filter_.setInputCloud(global_map_ptr_);
        display_filter_.filter(*global_map_ptr);
        return true;
    }
    return false;
}

bool FrontEnd::GetCurrentScan(CloudData::CLOUD_PTR& current_scan_ptr) {
    display_filter_.setInputCloud(result_cloud_ptr_);
    display_filter_.filter(*current_scan_ptr);
    return true;
}
         

        
    }
