#include "lidar_localization/publisher/cloud_publisher.hpp"

namespace lidar_localization
{
    CloudPublisher::CloudPublisher
    (ros::NodeHandle& nh, std::string topic_name, size_t buff_size, 
    std::string frame_id):nh_(nh), frame_id_(frame_id)
    {
        publisher_ = nh_.advertise<sensor_msgs::PointCloud2>(topic_name, buff_size);
        //这句是很重要的，意思就是
        //用于发布sensor_msgs::PointCloud2,这一句就是决定了要发布话题，
        //包括，如果想要发布新的话题名称，那么我也能这么做
    }

    void CloudPublisher::Publish(CloudData::CLOUD_PTR cloud_ptr_input)
    //输入的是一个智能指针
    {
        //这一块就是 之前定义的缩写，定义的是一个指针，保存点云的
        sensor_msgs::PointCloud2Ptr cloud_ptr_output(new sensor_msgs::PointCloud2());
       //创建的输出点云类型，开辟了一个新的地址用来放它

        pcl::toROSMsg(*cloud_ptr_input, *cloud_ptr_output);//消息类型转换
        cloud_ptr_output->header.stamp = ros::Time::now();//时间戳
        cloud_ptr_output->header.frame_id = frame_id_;//帧id，这两步对于时间同步和数据处理重要
        publisher_.publish(*cloud_ptr_output);
        //这里，这里最终的消息发布，publisher_
        //这里做得操作是将pcl转为ros可以识别的格式
    }
}