#include "lidar_localization/publisher/odometry_publisher.hpp"

namespace lidar_localization
{
    OdometryPublisher::OdometryPublisher(ros::NodeHandle& nh, std::string topic_name, std::string base_frame_id, std::string child_frame_id, int buff_size)
    :nh_(nh)
    {
        publisher_ = nh_.advertise<nav_msgs::Odometry>(topic_name, buff_size);//这里，话题名词与存取数据大小被放入了publisher
        //ros中类型nav_msgs::Odometry是用于传递关于机器人或自动驾驶位置和运动状态的消息格式
        odometry_.header.frame_id = base_frame_id;
        odometry_.child_frame_id = child_frame_id;//坐标的赋值
    }
    
void OdometryPublisher::Publish(const Eigen::Matrix4f& transform_matrix)//坐标变换矩阵
{
    odometry_.header.stamp = ros::Time::now();//时间戳 

    odometry_.pose.pose.position.x = transform_matrix(0,3);//odometry中的pose包含geometry_msgs::Pose的对象
    odometry_.pose.pose.position.y = transform_matrix(1,3);
    odometry_.pose.pose.position.z = transform_matrix(2,3);
    //4维矩阵最后一列，用来表示平移的
    //描述了机器人在三维空间中的位置和方向

    Eigen::Quaternionf q;
    q = transform_matrix.block<3,3>(0,0);
    odometry_.pose.pose.orientation.x = q.x();//四元数的赋值
    odometry_.pose.pose.orientation.y = q.y();
    odometry_.pose.pose.orientation.z = q.z();
    odometry_.pose.pose.orientation.w = q.w();

    publisher_.publish(odometry_);
    //这里就是最后的，将我们收到的消息，放在了函数中，可以用以后面使用
}
} // namespace lidar_localization
