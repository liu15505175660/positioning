#ifndef LIDAR_LOCALIZATION_SENSOR_DATA_CLOUD_DATA_HPP_
#define LIDAR_LOCALIZATION_SENSOR_DATA_CLOUD_DATA_HPP_

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

namespace lidar_localization
{
	class CloudData
	{
		public:
		using POINT = pcl::PointXYZ;
		using CLOUD = pcl::PointCloud<POINT>;
		using CLOUD_PTR = CLOUD::Ptr;
		//using 这里是一个命名的别名，主要是用来提高代码可读性
		//就是这个玩意如果不进行命名别名，就变成了这样
		//pcl::PointCloud<PointXYZ>::Ptr
		//也就是分开了，点，点云，点云智能指针
		
		public:
		CloudData():cloud_ptr(new CLOUD())
		{
			//cloud_ptr是一个成员变量，这是创建了一个新的CLOUD对象，然后把这个的地址给了cloud_ptr
		}
		//构造函数，用以成员初始化的，不过这个形式为用的少
		public:
		double time = 0.0;
		CLOUD_PTR cloud_ptr;
	};
}
#endif
//就是定义了指针，时间开始，然后把数据进行了简化，不过我觉者简化挺好的
