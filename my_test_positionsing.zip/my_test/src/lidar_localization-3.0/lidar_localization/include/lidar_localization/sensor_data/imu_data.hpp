#ifndef LIDAR_LOCALIZATION_SENSOR_DATA_IMU_DATA_HPP_
#define LIDAR_LOCALIZATION_SENSOR_DATA_IMU_DATA_HPP_

#include <Eigen/Dense>

namespace lidar_localization
{
	class IMUData
	{
		public:
		struct LinearAcceleration
		{
			double x = 0.0;
			double y = 0.0;
			double z = 0.0;
			//惯导的线性加速度误差
		};
		
		struct AngularVelocity
		{
			double x = 0.0;
			double y = 0.0;
			double z = 0.0;
			//角度误差
		};
		
		struct Orientation
		{
			double x = 0.0;
			double y = 0.0;
			double z = 0.0;
			double w = 0.0;
		};//这是定义的一个四元数
		
		double time = 0.0;
		LinearAcceleration linear_acceleration;
		AngularVelocity angular_velocity;
		Orientation orientation;
		
		public:
		//四元数转换
		Eigen::Matrix3f GetOrientationMatrix()
		{
		Eigen::Quaterniond q(orientation.w, orientation.x, orientation.y, orientation.z);
		Eigen::Matrix3f matrix = q.matrix().cast<float>();
		//四元数转换矩阵
		return matrix;
		
		}
	};
}
#endif
