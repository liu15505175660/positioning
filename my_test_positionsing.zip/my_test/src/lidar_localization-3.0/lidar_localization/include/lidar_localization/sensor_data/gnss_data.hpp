#ifndef LIDAR_LOCALIZATION_SENSOR_DATA_GNSS_DATA_HPP_
#define LIDAR_LOCALIZATION_SENSOR_DATA_GNSS_DATA_HPP_

#include <vector>
#include <string>

#include "Geocentric/LocalCartesian.hpp"

using std::vector;
using std::string;

namespace lidar_localization
{
	class GNSSData
	{
		public:
		double time = 0.0;
		double longitude = 0.0;
		double latitude = 0.0;
		double altitude =0.0;
		double local_E = 0.0;
		double local_N = 0.0;
		double local_U = 0.0;
		int status = 0;
		int service = 0;
		//经纬之类的
		
		private:
		static GeographicLib::LocalCartesian geo_converter;
		//用来为所有类的实例提供一个统一的地理坐标到笛卡尔坐标的转换功能
		static bool origin_position_inited;
		//这个布尔变量用于标识是否已经初始化了 geo_converter 的原点。
		
		public:
		void InitOriginPosition();
		void UpdateXYZ();
	};
}
#endif
