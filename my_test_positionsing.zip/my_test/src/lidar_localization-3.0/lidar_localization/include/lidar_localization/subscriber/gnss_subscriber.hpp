#ifndef LIDAR_LOCALIZATION_SUBSCRIBER_GNSS_SUBSCRIBER_HPP_
#define LIDAR_LOCALIZATION_SUBSCRIBER_GNSS_SUBSCRIBER_HPP_

//看话题中有什么，这里话题里面存在gps，imu与cloud
//这样我们订阅就要订阅这几个，注意gnss也就是定位系统


#include <deque>
//这是引入STL中的deque容器类，是一个动态数组，用来高效从头部与尾部插入和删除数据

#include <ros/ros.h>
#include "sensor_msgs/NavSatFix.h"
//ros中自带，用来发布gnss的消息的，包括，经纬度、海拔、状态、服务类型与位置协方差
#include "lidar_localization/sensor_data/gnss_data.hpp"

namespace lidar_localization{
class GNSSSubscriber
{
	public:
	GNSSSubscriber(ros::NodeHandle& nh, std::string topic_name, size_t buff_size);//构造，接受三种消息类型
	GNSSSubscriber() = default;//进行默认构造，允许没有实例化参数时也可以被实例化
	void ParseData(std::deque<GNSSData>& deque_gnss_data);
	//接受一个std::deque<GNSSData>的引用类型参数
	//而且这是一个公共接口，接受的是下面的 new_gnss_data
	
	private:
	void msg_callback(const sensor_msgs::NavSatFixConstPtr& nav_sat_fix_ptr);
	//回调，处理GNSS的消息类型，引用传递，给nav_sat_fix_ptr
	
	private:
	ros::NodeHandle nh_;
	ros::Subscriber subscriber_;
	
	std::deque<GNSSData> new_gnss_data_;
};
}
#endif
